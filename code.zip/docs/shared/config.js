// استبدل القيم التالية بإعدادات تطبيق الويب من Firebase Console.
// هذه الإعدادات عامة بطبيعتها؛ الحماية الفعلية في قواعد Firebase المرفقة.
export const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// رقم واتساب مع رمز البلد دون + أو مسافات. مثال: 9647XXXXXXXXX
export const whatsappNumber = "963968103758";
