import { initializeApp } from 'https://www.gstatic.com/firebasejs/11.10.0/firebase-app.js';
import { getAuth } from 'https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js';
import { getFirestore } from 'https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js';
import { getStorage } from 'https://www.gstatic.com/firebasejs/11.10.0/firebase-storage.js';
import { firebaseConfig, whatsappNumber } from './config.js';

export { whatsappNumber };
export const configured = Boolean(
  firebaseConfig.apiKey && firebaseConfig.projectId && firebaseConfig.appId &&
  !Object.values(firebaseConfig).some(value => typeof value === 'string' && value.includes('YOUR_'))
);

const app = configured ? initializeApp(firebaseConfig) : null;
export const auth = app ? getAuth(app) : null;
export const db = app ? getFirestore(app) : null;
// getStorage لا ينشئ حاوية ولا يستدعي خدمة التخزين؛ الروابط الخارجية تعمل من دونه.
export const storage = app ? getStorage(app) : null;
